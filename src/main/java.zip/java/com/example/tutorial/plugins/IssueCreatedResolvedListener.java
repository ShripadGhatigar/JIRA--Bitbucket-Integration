package com.example.tutorial.plugins;

import com.atlassian.event.api.EventListener;
import com.atlassian.event.api.EventPublisher;
import com.atlassian.jira.event.issue.IssueEvent;
import com.atlassian.jira.event.type.EventType;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.context.IssueContext;
import com.atlassian.jira.issue.issuetype.IssueType;
//import com.atlassian.plugin.spring.scanner.annotation.imports.JiraImport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
import com.atlassian.jira.extension.JiraStartedEvent;
import javax.inject.Inject;
import com.atlassian.plugin.spring.scanner.annotation.export.ExportAsService;
import com.atlassian.plugin.spring.scanner.annotation.imports.ComponentImport;
import com.atlassian.sal.api.lifecycle.LifecycleAware;
import com.atlassian.jira.event.user.LoginEvent;
import com.atlassian.jira.component.ComponentAccessor;
import org.springframework.stereotype.Component;
import javax.inject.Named;
import java.io.IOException;
import org.apache.commons.codec.binary.Base64;
import java.io.File;
import org.apache.http.client.ClientProtocolException;
import java.io.IOException;

@ExportAsService
@Component
@Named("eventListener")
public class IssueCreatedResolvedListener implements InitializingBean, DisposableBean {

    // public static  String IMPORTED_SCENARIO_DIRECTORY = System.getProperty("importedScenarioDirectory", "target/TestsImportedFromJira");

    public static Issue issue;
    public static final Logger log;
    public static Object obj;

    static {
        log = LoggerFactory.getLogger(IssueCreatedResolvedListener.class);
        log.warn("\n\n\t#+#+# IssueCreatedResolvedListener: STATIC INITIALIZIER\n");
    }

    @ComponentImport
    private final EventPublisher eventPublisher;

    /*@Inject
    public IssueCreatedResolvedListener(EventPublisher eventPublisher) {
        this.eventPublisher = eventPublisher;
    }*/
    @Inject
    public IssueCreatedResolvedListener(final EventPublisher eventPublisher) {
        System.out.println("Program is started");
        this.eventPublisher = eventPublisher;
        log.warn("\n\n\t#+#+# IssueCreatedResolvedListener: DEFAULT CONSTRUCTOR\n");
    }

    /**
     * Called when the plugin has been enabled.
     *
     * @throws Exception
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        log.info("Enabling plugin");

        eventPublisher.register(this);
    }

    /**
     * Called when the plugin is being disabled or removed.
     *
     * @throws Exception
     */


   /* @Override
    public void onStart()
    {
        log.warn("\n\n\t#+#+# IssueCreatedResolvedListener: LIFECYCLEAWARE ONSTART\n");
        log.warn("\n\n\t#+#+# IssueCreatedResolvedListener: eventPublisher is " + eventPublisher + " \n");
        if (eventPublisher == null)
            eventPublisher = ComponentAccessor.getComponent(EventPublisher.class);
        log.warn("\n\n\t#+#+# IssueCreatedResolvedListener: eventPublisher is " + eventPublisher + " \n");
        if (eventPublisher != null)
            eventPublisher.register(this);
    }

    @Override
    public void onStop()
    {
        log.warn("\n\n\t#+#+# IssueCreatedResolvedListener: ONSTOP\n");
    }*/
    @EventListener
    public static void processIssueEvent(IssueEvent issueEvent) throws ClientProtocolException, IOException {
        Long eventTypeId = issueEvent.getEventTypeId();

        issue = issueEvent.getIssue();
        String value = JiraRest.getCucumbervalue(issue.getKey());
        log.info("####The Value of JIRA Test is " + value);
        if (value.equalsIgnoreCase("cucumber")) {
            // if it's an event we're interested in, log it
            if (eventTypeId.equals(EventType.ISSUE_CREATED_ID)) {
                log.info("\n\n\t#+#+# Issue {} has been created at {}.\n", issue.getKey(), issue.getCreated());
                getIssuekeyfromJIRA();
            } else if (eventTypeId.equals(EventType.ISSUE_UPDATED_ID)) {
                log.info("\n\n\t#+#+# Issue {} has been updated at {}.\n", issue.getKey(), issue.getUpdated());
                getIssuekeyfromJIRA();
            } else if (eventTypeId.equals(EventType.ISSUE_DELETED_ID)) {
                log.info("\n\n\t#+#+# Issue {} has been Deleted at {}.\n", issue.getKey(), issue.getUpdated());
                getIssuekeyfromJIRA();
                //log.info("\n\n\t#+#+# Issue {} description is  {}.\n", issue.getDescription());
                //String Description = issue.getDescription();
                //System.out.println("The Description is " + Description);
                //log.info("\n\n\t#+#+# Issue {} type is  {}.\n", issue.getIssueType());
                // log.info("\n\n\t#+#+# Issue {} Summary  {}.\n", issue.getSummary());

            } else {
                log.warn("\n\n\t#+#+# Unhandled event type\n");
            }
        }
    }




    @EventListener
    public void processLoginEvent(LoginEvent loginEvent)
    {
        log.warn("\n\n\t#+#+# IssueCreatedResolvedListener: processLoginEvent (" + loginEvent.getUser().getUsername() + ") \n");
    }



    @Override
    public void destroy() throws Exception {
        log.info("Disabling plugin");
        if (eventPublisher != null)
            eventPublisher.unregister(this);
    }

    private static String encodeBase64String(String inputString) {
        return Base64.encodeBase64URLSafeString(inputString.getBytes());
    }

    private static boolean fileExists(String pathToFile) {
        return new File(pathToFile).exists();
    }

    public static void makeDirectory(String newDirString) {
        File file = new File(newDirString);
        if (!file.exists()) {
            if (file.mkdir()) {
                System.out.println("\ninfo: Directory was created!\n");
            } else {
                System.out.println("\nerror: Failed to create directory!\n");
            }
        }
    }

public static void getIssuekeyfromJIRA(){
    String[] command = {"C:\\Users\\shripadg\\AppData\\Local\\Apps\\curl-7.46.0-win64\\curl-7.46.0-win64\\bin\\curl.exe", "-D-", "-X", "GET", "-H",
            "Authorization: Basic " + encodeBase64String("admin" + ":" + "admin"),
            "http://localhost:2990/jira" + "/rest/raven/1.0/export/test?keys=" + issue.getKey()
    };
    ProcessBuilder process = new ProcessBuilder(command);
    Process p;
    log.info(" *********The Process**********  " + process.toString() +" "+ issue.getKey());


    try {
        System.out.println("\ninfo: Starting process that accepts curl GET command\n");
        p = process.start();
        log.info(" The Process is started accepting the Curl Get Commands " + p.toString() +" "+ issue.getKey());

        // IssueCreatedResolvedListener.makeDirectory(IMPORTED_SCENARIO_DIRECTORY + issue.getKey() + "/tests_imported_from_jira.feature" );
    } catch (IOException e) {
        log.error("\nerror: Tried to execute curl command and output to a file, something went wrong\n");
        e.printStackTrace();
    }
}



}



 /*public static void importTestsFromJIRA(String pathToOutputFile) {
        String[] command = {"C:\\Users\\shripadg\\AppData\\Local\\Apps\\curl-7.46.0-win64\\curl-7.46.0-win64\\bin\\curl.exe", "-D-", "-X", "GET", "-H",
                "Authorization: Basic " + encodeBase64String("admin" + ":" + "admin"),
                "http://localhost:2990/jira" + "/rest/raven/1.0/export/test?keys=" + issue.getKey(), "-o", pathToOutputFile
        };
        ProcessBuilder process = new ProcessBuilder(command);
        Process p;
        log.info(" The Process  " + process);
        try {
            System.out.println("\ninfo: Starting process that accepts curl GET command\n");
            p = process.start();
            log.info(" The Process P " + p);
        } catch (IOException e) {
            System.out.print("\nerror: Tried to execute curl command and output to a file, something went wrong\n");
            e.printStackTrace();
        }
        do {
            System.out.println("\ninfo: Checking if tests are imported and put in a new file\n");
            try {
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
            }
        } while (!fileExists(pathToOutputFile));
*/


        /* else if (eventTypeId.equals(EventType.ISSUE_RESOLVED_ID))
        {
            log.warn("\n\n\t#+#+# Issue {} has been resolved at {}.\n", issue.getKey(), issue.getResolutionDate());
        }
        else if (eventTypeId.equals(EventType.ISSUE_CLOSED_ID))
        {
            log.warn("\n\n\t#+#+# Issue {} has been closed at {}.\n", issue.getKey(), issue.getUpdated());
        } */

//@EventListener
//    public void onIssueEvent(IssueEvent issueEvent) {
//        log.info("inside onIssueEvent");
//        Long eventTypeId = issueEvent.getEventTypeId();
//        log.info("the Event Type id is ",issueEvent.getEventTypeId());
//        //System.out.println("The EventType ID is " +eventTypeId);
//
//
//        Issue issue = issueEvent.getIssue();
//         log.info("the Issue is ",issueEvent.getIssue());
//           // System.out.println("The Issue Type is " +issue);
//        if (eventTypeId.equals(EventType.ISSUE_CREATED_ID)) {
//            log.info("Issue {} has been created at {}.", issue.getId(), issue.getKey(), issue.getCreated());
//        } else if (eventTypeId.equals(EventType.ISSUE_RESOLVED_ID)) {
//            log.info("Issue {} has been resolved at {}.", issue.getKey(), issue.getResolutionDate());
//        } else if (eventTypeId.equals(EventType.ISSUE_CLOSED_ID)) {
//            log.info("Issue {} has been closed at {}.", issue.getKey(), issue.getUpdated());
//        }
//
//        String description = issue.getDescription();
//        log.info("the issue description is " , issue.getDescription());
//        IssueType issuetype =issue.getIssueType();
//        log.info("the issue type is " , issue.getIssueType());
//        log.info("the issue is " , issue.getIssueTypeId());
//    }