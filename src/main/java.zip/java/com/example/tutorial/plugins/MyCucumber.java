package com.example.tutorial.plugins;

import cucumber.api.junit.Cucumber;
import cucumber.runtime.Runtime;
import cucumber.runtime.RuntimeOptions;
import cucumber.runtime.io.ResourceLoader;
import java.io.IOException;
import org.junit.runners.model.InitializationError;



public class MyCucumber extends Cucumber {

    public static  String IMPORTED_SCENARIO_DIRECTORY = System.getProperty("importedScenarioDirectory", "target/TestsImportedFromJira");

    public MyCucumber(Class clazz) throws InitializationError, IOException {
        super(clazz);
        System.out.println(" Inside the myCucumber Class ");
    }

    @Override
    protected Runtime createRuntime(ResourceLoader resourceLoader, ClassLoader classLoader, RuntimeOptions runtimeOptions) throws InitializationError, IOException {

        String issueKey = IssueCreatedResolvedListener.issue.getKey().toString();

        System.out.println(" Issue Key is " +issueKey );
        System.out.println(" My Cucumber class is running ");

        IssueCreatedResolvedListener.makeDirectory(IMPORTED_SCENARIO_DIRECTORY + issueKey + "/tests_imported_from_jira.feature" );

       // IssueCreatedResolvedListener.importTestsFromJIRA(IMPORTED_SCENARIO_DIRECTORY + "/tests_imported_from_jira.feature" );
        return super.createRuntime(resourceLoader, classLoader, runtimeOptions);
    }
}
